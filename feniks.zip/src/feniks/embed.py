from typing import List, Tuple, Dict, Any

import numpy as np
from sentence_transformers import SentenceTransformer
from sklearn.feature_extraction.text import TfidfVectorizer

from feniks.types import Chunk

def build_tfidf(chunks: List[Chunk]) -> Tuple[TfidfVectorizer, Any]:
    """
    Builds a TF-IDF vectorizer and transforms the chunk texts.
    """
    corpus = [c.text for c in chunks]
    vec = TfidfVectorizer(
        token_pattern=r"[A-Za-z0-9_#\-$]{2,}",
        ngram_range=(1, 2),
        min_df=2,
        max_features=50000
    )
    X = vec.fit_transform(corpus)  # csr_matrix
    return vec, X

def get_embedding_model(name: str) -> SentenceTransformer:
    """
    Loads and returns a SentenceTransformer model.
    """
    return SentenceTransformer(name)

def create_dense_embeddings(model: SentenceTransformer, chunks: List[Chunk]) -> np.ndarray:
    """
    Creates dense embeddings for a list of chunks.
    """
    texts = [c.text[:5000] for c in chunks]  # Protect memory
    # normalize_embeddings=True makes embeddings cosine-comparable
    embs = model.encode(texts, normalize_embeddings=True, batch_size=64, show_progress_bar=True)
    return np.array(embs)