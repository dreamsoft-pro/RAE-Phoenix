module.exports = function (appOptions) {

    appOptions.apiUrl = 'http://localtest.me/api/';
    appOptions.authUrl = 'http://authapp.localtest.me/';
    appOptions.staticUrl = 'http://localtest.me/static/';
    appOptions.socketUrl = 'http://authapp.localtest.me';
    appOptions.editorUrl = 'http://editor.localtest.me/';
    appOptions.id = '25';
    appOptions.domainID = '2';
    appOptions.gaCodes = {
        'default': '$INDEX_GA_CODE'
    };

    appOptions.mainFolders = {
        'default': 'dist'
    };

    appOptions.seo = {
        'default': {
            title: '$INDEX_SEO_TITLE',
            description: '$INDEX_SEO_DESCRIPTION',
            keywords: '$INDEX_SEO_KEYWORDS'
        },

    };

    appOptions.googleWebTools = {
        'default': '$INDEX_SEARCH_CONSOLE_CODE',

    };

    function get() {
        return appOptions;
    }

    return {
        get: get
    }
};
